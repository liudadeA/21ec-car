/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @文件           : main.c
  * @简介          : 智能送药小车主程序
  ******************************************************************************
  * @注意
  *
  * Copyright (c) 2025 STMicroelectronics.
  * 保留所有权利。
  *
  * 本软件的许可条款可在该软件组件根目录下的LICENSE文件中找到。
  * 如果本软件未附带LICENSE文件，则按AS-IS方式提供。
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ring_buffer.h"
#include "usart_handler.h"
#include <string.h>
#include <stdio.h>
#include "Control.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// 系统状态枚举
typedef enum {
    SYS_INIT = 0,                  // 系统初始化
    SYS_WAITING_MEDICINE,          // 等待装药品
    SYS_LINE_TRACKING,             // 循线行驶
    SYS_CROSS_PROCESSING,          // 路口处理
    SYS_ARRIVED,                   // 到达目的地
    SYS_MISSION_COMPLETE,          // 任务完成
    SYS_ERROR                      // 错误状态
} SystemState_t;

// 电机动作枚举
typedef enum {
    MOTOR_ACT_STOP,                // 停止
    MOTOR_ACT_FORWARD,             // 前进
    MOTOR_TURN_LEFT,               // 原地左转
    MOTOR_TURN_RIGHT,              // 原地右转
    MOTOR_TURN_AROUND,             // 掉头(180度)
    MOTOR_ADJUST_LEFT,             // 轻微左调
    MOTOR_ADJUST_RIGHT,            // 轻微右调
    MOTOR_CURVE_LEFT,              // 大曲线左转
    MOTOR_CURVE_RIGHT              // 大曲线右转
} MotorAction_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MAX_CROSS_RECORDS     20    // 最大路口记录数
#define TURN_DELAY_MS         2000  // 90度原地转向的延迟时间(毫秒)
#define AROUND_DELAY_MS       4000  // 180度掉头的延迟时间(毫秒)
#define SPEED_FORWARD         10.0f // 前进速度
#define SPEED_ADJUST_FACTOR   1.2f  // 轻微调整的速度系数
#define SPEED_CURVE_FACTOR    0.3f  // 大曲线转向系数(例如：内侧车轮30%速度)
#define PI_UART               &huart2 // 与树莓派通信的UART

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
// UART环形缓冲区
RingBuffer usart1_rx_buffer = {0};
RingBuffer usart2_rx_buffer = {0};
RingBuffer usart3_rx_buffer = {0};

// 系统状态
volatile SystemState_t system_state = SYS_INIT;
volatile uint8_t medicine_taken = 0;          // 药品已放置标志
volatile uint8_t sensor_state_8 = 0;          // 8位传感器状态
volatile uint8_t In_Turn = 0;                 // 正在转向标志

// 返程路径记录
uint8_t cross_go[MAX_CROSS_RECORDS];          // 去程路口记录
uint8_t cross_cnt_go = 0;                     // 去程路口计数
uint8_t GO_or_BACK = 0;                       // 0-去程, 1-返程

// 通信缓冲区
uint16_t track_pkt_len = 0;                   // 新传感器数据标志
extern uint8_t frame_buffer[];                // 假设在usart_handler.c中定义
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void System_Init(void);
static void Process_Communication(void);
static void Line_Tracking_Task(void);
static void Execute_Line_Tracking(uint8_t sensor_state_8);
static void Handle_Cross_Road(void);
static void Execute_Motor_Action(MotorAction_t action);
static void Handle_Arrival(void);
static void Execute_Cross_Action(uint8_t action);
static void Controlled_Delay(uint32_t delay_ms);
static void Send_Status_Message(const char* message);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @简介  应用程序入口点。
  * @返回值 int
  */
int main(void)
{
    /* MCU配置--------------------------------------------------------*/
    HAL_Init();
    SystemClock_Config();

    /* 初始化所有配置的外设 */
    MX_GPIO_Init();
    MX_USART1_UART_Init();
    MX_USART2_UART_Init();
    MX_USART3_UART_Init();
    MX_TIM2_Init();
    MX_TIM3_Init();
    MX_TIM4_Init();
    MX_TIM8_Init();

    /* USER CODE BEGIN 2 */
    System_Init();
    Pi_Start();
    /* USER CODE END 2 */

    /* 无限循环 */
    /* USER CODE BEGIN WHILE */
    Send_Status_Message("智能送药小车启动...\r\n");
    
    // 1. 等待药品装载
    system_state = SYS_WAITING_MEDICINE;
    printf("等待药品装载...\r\n");
    while(medicine_taken == 0) {
        // 该标志可通过按键中断或命令设置
        HAL_Delay(10);
    }
    
    printf("药品已装载。开始循线任务。\r\n");
    medicine_taken = 0;
    system_state = SYS_LINE_TRACKING;

    while (1)
    {
        /* USER CODE END WHILE */
        /* USER CODE BEGIN 3 */
        
        // 处理传入的传感器数据和其他通信
        Process_Communication();
        
        // 主状态机
        switch(system_state) {
            case SYS_LINE_TRACKING:
                Line_Tracking_Task();
                break;
                
            case SYS_CROSS_PROCESSING:
                Handle_Cross_Road();
                break;
                
            case SYS_ARRIVED:
                Handle_Arrival();
                break;
                
            case SYS_MISSION_COMPLETE:
                // 最终状态，不执行任何操作
                break;

            case SYS_ERROR:
                printf("系统错误! 停止运行。\r\n");
                Car_Stop();
                while(1); // 停机
                break;
                
            default:
                break;
        }
        
        HAL_Delay(10); // 主循环延迟
    }
    /* USER CODE END 3 */
}

/**
  * @简介 系统时钟配置
  * @返回值 None
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 4;
    RCC_OscInitStruct.PLL.PLLN = 168;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 4;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) {
        Error_Handler();
    }
}

/* USER CODE BEGIN 4 */
/**
  * @简介 系统初始化
  */
static void System_Init(void)
{
    RingBuffer_Init(&usart1_rx_buffer);
    RingBuffer_Init(&usart2_rx_buffer);
    RingBuffer_Init(&usart3_rx_buffer);
    
    HAL_UART_Receive_IT(&huart1, &usart1_rx_buffer.buffer[usart1_rx_buffer.head], 1);
    HAL_UART_Receive_IT(&huart2, &usart2_rx_buffer.buffer[usart2_rx_buffer.head], 1);
    HAL_UART_Receive_IT(&huart3, &usart3_rx_buffer.buffer[usart3_rx_buffer.head], 1);
    
    Motor_Init();
    Motor_PID_Init();
    Car_Stop();
    
    system_state = SYS_INIT;
    GO_or_BACK = 0;
    cross_cnt_go = 0;
    In_Turn = 0;
}

/**
  * @简介 处理来自传感器和树莓派的通信数据
  */
static void Process_Communication(void)
{
    // 检查UART2的新数据包(传感器数据或树莓派命令)
    static char rx_track_buf[MAX_FRAME_SIZE];
    uint16_t len = GetPacket(PI_UART, &usart2_rx_buffer, rx_track_buf);
    
    if(len > 0) {
        // 如果处于循线模式，这是传感器数据
        if (system_state == SYS_LINE_TRACKING) {
            sensor_state_8 = rx_track_buf[1]; // 假设数据在第二个字节
            track_pkt_len = len; // 为Line_Tracking_Task设置标志
        }
    }
    
    // 其他通信处理可以放在这里(例如：蓝牙、调试UART)
    USART1_ProcessReceivedData(); 
}

/**
  * @简介 主循线任务，从主循环调用
  */
static void Line_Tracking_Task(void)
{
    // 仅当有新数据且不在转向时处理新传感器数据
    if(track_pkt_len && !In_Turn) {
        track_pkt_len = 0; // 消费数据包
        Execute_Line_Tracking(sensor_state_8);
    }
}

/**
  * @简介 基于8传感器状态执行循线逻辑。
  * 这是运动的核心决策函数。
  * @param sensor_state_8: 来自传感器阵列的8位值。
  */
static void Execute_Line_Tracking(uint8_t sensor_state_8)
{
    // 首先，检查特殊状态(路口或丢失线路)
    if (sensor_state_8 == STATE_CROSSROAD) {
        printf("检测到路口(0xFF)。\r\n");
        system_state = SYS_CROSS_PROCESSING;
        return;
    }
    
    if (sensor_state_8 == STATE_LOST_LINE) {
        printf("丢失线路(0x00)。进入到达流程。\r\n");
        system_state = SYS_ARRIVED;
        return;
    }

    // 标准循线逻辑
    switch(sensor_state_8) {
        case STATE_STRAIGHT:
            Execute_Motor_Action(MOTOR_ACT_FORWARD);
            break;
            
        case STATE_ADJUST_LEFT_1:
        case STATE_ADJUST_LEFT_2:
            Execute_Motor_Action(MOTOR_ADJUST_LEFT);
            break;
            
        case STATE_ADJUST_RIGHT_1:
        case STATE_ADJUST_RIGHT_2:
            Execute_Motor_Action(MOTOR_ADJUST_RIGHT);
            break;
            
        case STATE_CURVE_LEFT:
            Execute_Motor_Action(MOTOR_CURVE_LEFT);
            break;
            
        case STATE_CURVE_RIGHT:
            Execute_Motor_Action(MOTOR_CURVE_RIGHT);
            break;
            
        default:
            // 如果处于未知状态，作为 fallback 继续直行
            Execute_Motor_Action(MOTOR_ACT_FORWARD);
            break;
    }
}

/**
  * @简介 处理路口逻辑。
  */
static void Handle_Cross_Road(void)
{
    Execute_Motor_Action(MOTOR_ACT_STOP);
    printf("检测到路口(0xFF)。\r\n");
    printf("等待来自树莓派的转向命令(w/a/d)...\r\n");
    
    char action = 0;
    static char rx_buf[5] = {0};
    uint16_t len = 0;

    // 等待来自树莓派的命令
    while(len == 0) {
        len = GetPacket(PI_UART, &usart2_rx_buffer, rx_buf);
        HAL_Delay(10);
    }
    action = rx_buf[1]; // 假设命令在第二个字节
    
    printf("收到命令: '%c'\r\n", action);
    
    // 如果是去程，记录转向以便返程
    if(GO_or_BACK == 0 && cross_cnt_go < MAX_CROSS_RECORDS) {
        cross_go[cross_cnt_go] = action;
        cross_cnt_go++;
    }
    
    Execute_Cross_Action(action);
    
    // 恢复循线
    system_state = SYS_LINE_TRACKING;
}

/**
  * @简介 处理到达病房或药房的逻辑。
  */
static void Handle_Arrival(void)
{
    Execute_Motor_Action(MOTOR_ACT_STOP);
    printf("到达目的地。等待树莓派命令...\r\n");

    char command = 0;
    static char rx_buf[5] = {0};
    uint16_t len = 0;

    // 等待来自树莓派的命令('f'或'e')
    while(command != 'f' && command != 'e') {
        len = GetPacket(PI_UART, &usart2_rx_buffer, rx_buf);
        if (len > 0) {
            command = rx_buf[1];
        }
        HAL_Delay(10);
    }

    printf("收到命令: '%c'\r\n", command);

    if (command == 'f' && GO_or_BACK == 0) { // 到达病房
        printf("到达病房，等待取药\r\n");
        HAL_GPIO_WritePin(RED_LED_PIN_GPIO_Port, RED_LED_PIN_Pin, GPIO_PIN_SET);
        
        while(medicine_taken == 0) {
            HAL_Delay(100); // 等待按键按下
        }
        medicine_taken = 0;
        HAL_GPIO_WritePin(RED_LED_PIN_GPIO_Port, RED_LED_PIN_Pin, GPIO_PIN_RESET);
        
        printf("药品已投放。开始返程。\r\n");
        Execute_Motor_Action(MOTOR_TURN_AROUND);
        
        printf("返程开始。\r\n");
        Send_Packet(PI_UART, "b", 1);
        
        GO_or_BACK = 1; // 设置为返程模式
        system_state = SYS_LINE_TRACKING; // 恢复循线
        
    } else if (command == 'e' && GO_or_BACK == 1) { // 返回药房
        printf("返回药房。任务完成。\r\n");
        HAL_GPIO_WritePin(GREEN_LED_PIN_GPIO_Port, GREEN_LED_PIN_Pin, GPIO_PIN_SET);
        system_state = SYS_MISSION_COMPLETE;
        while(1) { // 永久停止
            HAL_Delay(1000);
        }
    } else {
        printf("错误");
        system_state = SYS_ERROR;
    }
}


/**
  * @简介 执行特定的电机动作。
  * @param action: 要执行的电机动作。
  */
static void Execute_Motor_Action(MotorAction_t action)
{
    switch(action) {
        case MOTOR_ACT_STOP:
            Car_Stop();
            break;
            
        case MOTOR_ACT_FORWARD:
            Set_Motor_Target_Speed(SPEED_FORWARD, -SPEED_FORWARD);
            break;
            
        case MOTOR_ADJUST_LEFT:
            // 右轮加速以左转
            Set_Motor_Target_Speed(SPEED_FORWARD / SPEED_ADJUST_FACTOR, -SPEED_FORWARD);
            break;
            
        case MOTOR_ADJUST_RIGHT:
            // 左轮加速以右转
            Set_Motor_Target_Speed(SPEED_FORWARD, -SPEED_FORWARD / SPEED_ADJUST_FACTOR);
            break;
            
        case MOTOR_CURVE_LEFT:
            // 左轮减速以大曲线左转
            Set_Motor_Target_Speed(SPEED_FORWARD * SPEED_CURVE_FACTOR, -SPEED_FORWARD);
            break;
            
        case MOTOR_CURVE_RIGHT:
             // 右轮减速以大曲线右转
            Set_Motor_Target_Speed(SPEED_FORWARD, -SPEED_FORWARD * SPEED_CURVE_FACTOR);
            break;
            
        case MOTOR_TURN_AROUND:
            Set_Motor_Target_Speed(8.0f, 8.0f); // 原地掉头
            Motor_Control_Task();
            Controlled_Delay(AROUND_DELAY_MS);
            Car_Stop();
            break;

        default:
            Car_Stop();
            break;
    }
    
    Motor_Control_Task(); // 应用新速度
}

/**
  * @简介 在路口执行定时原地转向。
  * @param action: 转向方向字符('w', 'a', 'd')。
  */
static void Execute_Cross_Action(uint8_t action)
{
    switch(action) {
        case 'w': // 直行
            printf("[电机] 直行通过路口。\r\n");
            Set_Motor_Target_Speed(SPEED_FORWARD, -SPEED_FORWARD);
            Motor_Control_Task();
            HAL_Delay(500); // 向前移动一点以离开路口线
            break;
            
        case 'a': // 左转
            printf("[电机] 左转90度。\r\n");
            Set_Motor_Target_Speed(-8.0f, -8.0f); // 原地左转
            Motor_Control_Task();
            Controlled_Delay(TURN_DELAY_MS);
            Car_Stop();
            break;
            
        case 'd': // 右转
            printf("[电机] 右转90度。\r\n");
            Set_Motor_Target_Speed(8.0f, 8.0f); // 原地右转
            Motor_Control_Task();
            Controlled_Delay(TURN_DELAY_MS);
            Car_Stop();
            break;
            
        default:
            printf("未知转向命令: %c\r\n", action);
            break;
    }
    
    // 清除转向期间收到的UART缓冲区中的任何传感器数据
    usart2_rx_buffer.tail = usart2_rx_buffer.head;
}

/**
  * @简介 保持In_Turn标志有效的阻塞延迟。
  * @param delay_ms: 延迟时间(毫秒)。
  */
static void Controlled_Delay(uint32_t delay_ms)
{
    In_Turn = 1;
    uint32_t start_tick = HAL_GetTick();
    while((HAL_GetTick() - start_tick) < delay_ms) {
        // 此循环会阻塞，但对于复杂项目，基于定时器的非阻塞方法会更好
    }
    In_Turn = 0;
    printf("转向/延迟完成。\r\n");
}

/**
  * @简介 通过调试UART发送状态消息。
  * @param message: 要发送的字符串消息。
  */
static void Send_Status_Message(const char* message)
{
    HAL_UART_Transmit(&huart1, (uint8_t*)message, strlen(message), 100);
}

/* USER CODE END 4 */

/**
  * @简介 错误处理函数
  * @返回值 None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    __disable_irq();
    while (1) {
    }
    /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @简介 断言失败处理函数
  * @param  file: 源文件名指针
  * @param  line: 失败的行号
  * @返回值 None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
    /* USER CODE BEGIN 6 */
    /* 用户可以添加自己的文件和行号处理逻辑 */
    /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
