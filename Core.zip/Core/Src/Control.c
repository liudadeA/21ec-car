#include "stm32f4xx.h"                  // Device header
#include "Control.h"
#include <stdlib.h>  // 包含 abs 函数的声明
/**
  * @brief  初始化电机控制相关引脚和PWM
  * @param  None
  * @retval None
  */
void Motor_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
 
    // 初始化为停止状态
    HAL_GPIO_WritePin(GPIOA, AO1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, AO2_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, BO1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, BO2_PIN, GPIO_PIN_RESET);	
	
    // 启动双通道PWM输出
    HAL_TIM_PWM_Start(MOTOR_TIM, PWM_CHANNEL_LEFT);
    HAL_TIM_PWM_Start(MOTOR_TIM, PWM_CHANNEL_RIGHT);
}

/**
  * @brief  控制电机方向
  * @param  dir: 方向（MOTOR_STOP / MOTOR_FORWARD / MOTOR_BACKWARD）
  * @retval None
  */
void Motor_SetDirection(uint8_t dir)
{
    switch(dir)
    {
        case MOTOR_STOP:
            HAL_GPIO_WritePin(GPIOA, AO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, AO2_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, BO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, BO2_PIN, GPIO_PIN_RESET);
            break;
            
        case MOTOR_FORWARD:
            HAL_GPIO_WritePin(GPIOA, AO1_PIN, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, AO2_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, BO1_PIN, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, BO2_PIN, GPIO_PIN_RESET);
            break;
            
        case MOTOR_BACKWARD:
            HAL_GPIO_WritePin(GPIOA, AO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, AO2_PIN, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, BO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, BO2_PIN, GPIO_PIN_SET);
            break;
            
        default:
            break;
    }
}

/**
  * @brief  设置右轮PWM占空比
  * @param  duty_percent: 占空比（0-100，对应0%-100%）
  * @retval None
  */
void Motor_Right_SetSpeed(uint8_t duty_percent)
{
    uint16_t arr = __HAL_TIM_GET_AUTORELOAD(MOTOR_TIM);
    uint16_t pulse = (duty_percent * (arr + 1)) / 100;
    
    if (pulse > arr) pulse = arr;  

    TIM_OC_InitTypeDef sConfigOC = {0};
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = pulse;  
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    
    if (HAL_TIM_PWM_ConfigChannel(MOTOR_TIM, &sConfigOC, PWM_CHANNEL_RIGHT) != HAL_OK)
    {
        Error_Handler();
    }
    HAL_TIM_PWM_Start(MOTOR_TIM, PWM_CHANNEL_RIGHT);
}

/**
  * @brief  设置左轮PWM占空比
  * @param  duty_percent: 占空比（0-100，对应0%-100%）
  * @retval None
  */
void Motor_Left_SetSpeed(uint8_t duty_percent)
{
    uint16_t arr = __HAL_TIM_GET_AUTORELOAD(MOTOR_TIM);
    uint16_t pulse = (duty_percent * (arr + 1)) / 100;
    
    if (pulse > arr) pulse = arr;  

    TIM_OC_InitTypeDef sConfigOC = {0};
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = pulse;  
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    
    if (HAL_TIM_PWM_ConfigChannel(MOTOR_TIM, &sConfigOC, PWM_CHANNEL_LEFT) != HAL_OK)
    {
        Error_Handler();
    }
    HAL_TIM_PWM_Start(MOTOR_TIM, PWM_CHANNEL_LEFT);
}

// 简单的延时计数器
static uint32_t delay_counter = 0;

void Timer_Delay_Start(uint32_t ms)
{
    delay_counter = ms;
    delay_ctrl.state = DELAY_RUNNING;
}

uint8_t Timer_Delay_IsComplete(void)
{
    if (delay_ctrl.state == DELAY_RUNNING) {
        if (delay_counter > 0) {
            delay_counter--;
            return 0;
        } else {
            delay_ctrl.state = DELAY_COMPLETE;
            return 1;
        }
    }
    return 1;
}

// 定时器中断回调函数
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM3) {
        system_tick_count++;
    }
}

/**
  * @brief  初始化PID控制器
  */
void PID_Init(PID_Controller *pid, float kp, float ki, float kd)
{
    pid->Kp = kp;
    pid->Ki = ki;
    pid->Kd = kd;
    
    pid->setpoint = 0.0f;
    pid->input = 0.0f;
    pid->output = 0.0f;
    
    pid->error = 0.0f;
    pid->last_error = 0.0f;
    pid->integral = 0.0f;
    pid->derivative = 0.0f;
    
    pid->output_min = -100.0f;
    pid->output_max = 100.0f;
    
    pid->last_time = HAL_GetTick();
    pid->enabled = 1;
    
    pid->integral_limit = 25.0f;  // 积分限制
    pid->dead_zone = 2.0f;        // 死区
}

/**
  * @brief  PID计算函数
  */
float PID_Compute(PID_Controller *pid, float input)
{
    if (!pid->enabled) {
        return 0.0f;
    }
    
    uint32_t now = HAL_GetTick();
    float dt = (float)(now - pid->last_time) / 1000.0f;
    
    if (dt <= 0.0f) {
        return pid->output;
    }
    
    // 计算误差
    pid->input = input;
    pid->error = pid->setpoint - pid->input;
    
    // 死区处理
    if (fabs(pid->error) < pid->dead_zone) {
        pid->error = 0.0f;
    }
    
    // 比例项
    float proportional = pid->Kp * pid->error;
    
    // 积分项
    if (fabs(pid->error) > 0.1f) {
        pid->integral += pid->error * dt;
        
        // 积分限幅
        if (pid->integral > pid->integral_limit) {
            pid->integral = pid->integral_limit;
        } else if (pid->integral < -pid->integral_limit) {
            pid->integral = -pid->integral_limit;
        }
    }
    
    float integral_term = pid->Ki * pid->integral;
    
    // 微分项
    pid->derivative = (pid->error - pid->last_error) / dt;
    float derivative_term = pid->Kd * pid->derivative;
    
    // PID输出
    pid->output = proportional + integral_term + derivative_term;
    
    // 输出限幅
    if (pid->output > pid->output_max) {
        pid->output = pid->output_max;
    } else if (pid->output < pid->output_min) {
        pid->output = pid->output_min;
    }
    
    // 更新历史值
    pid->last_error = pid->error;
    pid->last_time = now;
    
    return pid->output;
}

/**
  * @brief  设置PID目标值
  */
void PID_SetSetpoint(PID_Controller *pid, float setpoint)
{
    pid->setpoint = setpoint;
}

/**
  * @brief  重置PID控制器
  */
void PID_Reset(PID_Controller *pid)
{
    pid->error = 0.0f;
    pid->last_error = 0.0f;
    pid->integral = 0.0f;
    pid->derivative = 0.0f;
    pid->output = 0.0f;
    pid->last_time = HAL_GetTick();
}

/**
  * @brief  初始化编码器
  */
void Encoder_Init(Encoder_t *encoder, TIM_HandleTypeDef *htim)
{
    encoder->htim = htim;
    encoder->pulse_count = 0;
    encoder->last_pulse_count = 0;
    encoder->speed_rpm = 0.0f;
    encoder->last_time = HAL_GetTick();
    encoder->total_revolutions = 0.0f;
    encoder->speed_filter = 0.0f;
    encoder->last_speed = 0.0f;
}

/**
  * @brief  更新编码器数据
  */
void Encoder_Update(Encoder_t *encoder)
{
    uint32_t current_time = HAL_GetTick();
    uint32_t time_diff = current_time - encoder->last_time;
    
    if (time_diff >= SPEED_CALC_PERIOD) {
        // 读取编码器计数值
        encoder->pulse_count = (int32_t)__HAL_TIM_GET_COUNTER(encoder->htim);
        
        // 计算脉冲差值
        int32_t pulse_diff = encoder->pulse_count - encoder->last_pulse_count;
        
        // 处理计数器溢出
        if (pulse_diff > 32767) {
            pulse_diff -= 65536;
        } else if (pulse_diff < -32768) {
            pulse_diff += 65536;
        }
        
        // 计算转速（RPM）
        float raw_speed = (float)pulse_diff * 60.0f * 1000.0f / 
                         (ENCODER_RESOLUTION * GEAR_RATIO * time_diff);
        
        // 速度滤波
        //float alpha = 0.3f;  // 滤波系数
        encoder->speed_filter =  raw_speed ;
        encoder->speed_rpm = encoder->speed_filter;
        
        // 累计圈数
        encoder->total_revolutions += (float)pulse_diff / 
                                     (ENCODER_RESOLUTION * GEAR_RATIO);
        
        // 更新历史值
        encoder->last_pulse_count = encoder->pulse_count;
        encoder->last_time = current_time;
        encoder->last_speed = encoder->speed_rpm;
    }
}

/**
  * @brief  初始化电机PID控制系统
  */
void Motor_PID_Init(void)
{
    // 初始化编码器（TIM4和TIM8配置为编码器模式）
    Encoder_Init(&left_motor.encoder, &htim4);   // 左轮编码器
    Encoder_Init(&right_motor.encoder, &htim8);  // 右轮编码器
    
    // 初始化PID控制器
    PID_Init(&left_motor.pid, 4.0f, 1.4f, 0.1f);   // 
    PID_Init(&right_motor.pid, 4.0f, 1.4f, 0.1f);
//	PID_Init(&left_motor.pid, 10.0f, 4.0f, 4.0f);   // 
//  PID_Init(&right_motor.pid, 10.0f, 4.0f, 4.0f);
    
    // 初始化电机参数
    left_motor.target_speed = 0;
    left_motor.current_speed = 0;
    left_motor.enabled = 0;
    
    right_motor.target_speed = 0;
    right_motor.current_speed = 0;
    right_motor.enabled = 0;
    
    // 启动编码器定时器
    HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim8, TIM_CHANNEL_ALL);
    
    pid_control_enabled = 1;
}

/**
  * @brief  电机PID控制
  */
void Motor_PID_Control(Motor_t *motor, float target_speed)
{
    // 更新编码器数据
    Encoder_Update(&motor->encoder);
    
    // 设置目标速度
    motor->target_speed = target_speed;
    motor->current_speed = motor->encoder.speed_rpm;
    
    // 启用/禁用PID控制
    motor->enabled = (target_speed != 0.0f) ? 1 : 0;

    motor->pid.enabled = motor->enabled;
    
    // 计算PID输出
    PID_SetSetpoint(&motor->pid, target_speed);
    float pid_output = PID_Compute(&motor->pid, motor->current_speed);
    
    motor->pwm_output = (int16_t)pid_output;
}



/**
  * @brief  电机控制任务
  */
void Motor_Control_Task(void)
{
    static uint32_t last_control_time = 0;
    uint32_t current_time = HAL_GetTick();
    
    if (!pid_control_enabled) return;
    
    // 每20ms执行一次控制
   // if (current_time - last_control_time >= 20) {
        // 执行PID控制
        Motor_PID_Control(&left_motor, left_motor.target_speed);
        Motor_PID_Control(&right_motor, right_motor.target_speed);
        
        // 输出到电机驱动器
        TB6612_SetMotor(0, left_motor.pwm_output);
        TB6612_SetMotor(1, right_motor.pwm_output);
        
        last_control_time = current_time;
  //  }
}

/**
  * @brief  设置电机目标速度
  */
void Set_Motor_Target_Speed(float left_rpm, float right_rpm)
{
    left_motor.target_speed = left_rpm;
    right_motor.target_speed = right_rpm;
}

/**
  * @brief  重置编码器圈数计数
  */
void Reset_Encoder_Revolution_Count(void)
{
    left_motor.encoder.total_revolutions = 0.0f;
    right_motor.encoder.total_revolutions = 0.0f;
}



#include <stdbool.h>



/**
  * @brief  TB6612电机驱动函数
  */
void TB6612_SetMotor(uint8_t motor_id, int16_t speed)
{
	
	
	

    uint32_t pwm_value;
    
    // 限制速度范围
    if (speed > 100) speed = 100;
    if (speed < -100) speed = -100;
    
    // 计算PWM值
    pwm_value = (uint32_t)(abs(speed));
    
    if (motor_id == 0) {  // 左轮
        if (speed > 0) {
            // 正转
            HAL_GPIO_WritePin(GPIOA, AO1_PIN, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, AO2_PIN, GPIO_PIN_RESET);
        } else if (speed < 0) {
            // 反转
            HAL_GPIO_WritePin(GPIOA, AO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, AO2_PIN, GPIO_PIN_SET);
        } else {
            // 停止
            HAL_GPIO_WritePin(GPIOA, AO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, AO2_PIN, GPIO_PIN_RESET);
        }
        Motor_Left_SetSpeed(pwm_value);
    } else {  // 右轮
        if (speed > 0) {
            // 正转
            HAL_GPIO_WritePin(GPIOA, BO1_PIN, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, BO2_PIN, GPIO_PIN_RESET);
        } else if (speed < 0) {
            // 反转
            HAL_GPIO_WritePin(GPIOA, BO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, BO2_PIN, GPIO_PIN_SET);
        } else {
            // 停止
            HAL_GPIO_WritePin(GPIOA, BO1_PIN, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, BO2_PIN, GPIO_PIN_RESET);
        }
        Motor_Right_SetSpeed(pwm_value);
    }
}
void Car_Stop(void)
{
	
    // PWM输出为0
    Set_Motor_Target_Speed(0.0f, 0.0f);
}
bool Car_Turn_Left_90_And_Stop2s(void)
{
    static uint8_t state = 0; // 0:转弯 1:停2秒
    static uint32_t start_time = 0;
    static bool running = false;
    uint32_t now = HAL_GetTick();
    uint32_t turn_time = 300; // 1秒，需实车调试
    uint32_t stop_time = 2000; // 2秒

    if (!running) {
        state = 0;
        running = true;
        start_time = now;
    }

    if (state == 0) { // 转弯阶段
        Set_Motor_Target_Speed(0.0f, -8.0f);
        if (now - start_time >= turn_time) {
            state = 1;
            start_time = now;
						In_Turn = 1; //循迹用
					  printf("In Turn = : %d",In_Turn);
        }
        return false;
    } else if (state == 1) { // 停2秒阶段
       Car_Stop();
			 In_Turn = 0; //循迹用
			 printf("In Turn = : %d",In_Turn);
        if (now - start_time >= stop_time) {
            running = false;
            return true;
        }
        return false;
    }
    return false;
}


bool Car_Turn_Right_90_And_Stop2s(void)
{
    static uint8_t state = 0; // 0:转弯 1:停2秒
    static uint32_t start_time = 0;
    static bool running = false;
    uint32_t now = HAL_GetTick();
    uint32_t turn_time = 300; // 1秒，需实车调试
    uint32_t stop_time = 2000; // 2秒

    if (!running) {
        state = 0;
        running = true;
        start_time = now;
    }

    if (state == 0) { // 转弯阶段
        Set_Motor_Target_Speed(8.0f, 0.0f);
        if (now - start_time >= turn_time) {
            state = 1;
						In_Turn = 1; //循迹用
						printf("In Turn = : %d",In_Turn);
            start_time = now;
        }
        return false;
    } else if (state == 1) { // 停2秒阶段
       Car_Stop();
			 In_Turn = 0; //循迹用
			 printf("In Turn = : %d",In_Turn);
        if (now - start_time >= stop_time) {
            running = false;
            return true;
        }
        return false;
    }
    return false;
}

bool Car_Turn_Arounde_And_Stop2s(void)
{
    static uint8_t state = 0; // 0:转弯 1:停2秒
    static uint32_t start_time = 0;
    static bool running = false;
    uint32_t now = HAL_GetTick();
    uint32_t turn_time = 350; // 1秒，需实车调试
    uint32_t stop_time = 2000; // 2秒

    if (!running) {
        state = 0;
        running = true;
        start_time = now;
    }

    if (state == 0) { // 转弯阶段
        Set_Motor_Target_Speed(8.0f, 9.0f);
				In_Turn = 1; //循迹用
        if (now - start_time >= turn_time) {
            state = 1;
						
						printf("In Turn = : %d\r\n",In_Turn);
            start_time = now;
        }
        return false;
    } else if (state == 1) { // 停2秒阶段
       Car_Stop();
			 //In_Turn = 0; //循迹用
			 printf("In Turn = : %d\r\n",In_Turn);
        if (now - start_time >= stop_time) {
            running = false;
            return true;
        }
        return false;
    }
    return false;
}

bool Car_G0_Straight_And_Stop2s(void)
{
    static uint8_t state = 0; // 0:转弯 1:停2秒
    static uint32_t start_time = 0;
    static bool running = false;
    uint32_t now = HAL_GetTick();
    uint32_t turn_time = 300; // 1秒，需实车调试
    uint32_t stop_time = 700; // 2秒

    if (!running) {
        state = 0;
        running = true;
        start_time = now;
    }

    if (state == 0) { // 转弯阶段
        Set_Motor_Target_Speed(4.0f, -4.0f);
        if (now - start_time >= turn_time) {
            state = 1;
						In_Turn = 1; //循迹用
            start_time = now;
					printf("In Turn = : %d",In_Turn);
        }
        return false;
    } else if (state == 1) { // 停2秒阶段
       Car_Stop();
			 In_Turn = 0; //循迹用
			 printf("In Turn = : %d",In_Turn);
        if (now - start_time >= stop_time) {
            running = false;
            return true;
        }
        return false;
    }
    return false;
}

// deceleration: 每次循环目标速度减少的量，单位RPM
// 返回值：1=刹车完成，0=正在刹车
uint8_t Car_Active_Brake(float deceleration)
{
    static uint8_t braking = 0;
    static float left, right;

    if (!braking) {
        left = left_motor.current_speed;
        right = right_motor.current_speed;
        braking = 1;
    }

    // 逐步减小目标速度
    if (fabs(left) > deceleration) {
        left -= (left > 0 ? deceleration : -deceleration);
    } else {
        left = 0;
    }
    if (fabs(right) > deceleration) {
        right -= (right > 0 ? deceleration : -deceleration);
    } else {
        right = 0;
    }

    Set_Motor_Target_Speed(left, right);

    // 只要目标速度不为0，PID就会持续调节
    left_motor.enabled = 1;
    right_motor.enabled = 1;
    left_motor.pid.enabled = 1;
    right_motor.pid.enabled = 1;

    // 判断是否完全停止
    if (left == 0 && right == 0) {
        braking = 0; // 刹车完成
        return 1;
    }
    return 0;
}

