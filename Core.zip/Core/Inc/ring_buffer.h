#ifndef __RING_BUFFER_H
#define __RING_BUFFER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"
#include <string.h>

// ���λ���������
#define RING_BUFFER_SIZE 256
#define MAX_FRAME_SIZE 5
#define MAX_BT_FRAME_SIZE 32
#define TEST_STRING "usart1"
#define RESPONSE_STRING "usart1ok\r\n"

typedef struct {
    uint8_t buffer[RING_BUFFER_SIZE];
    volatile uint16_t head;
    volatile uint16_t tail;
    volatile uint16_t count;
} RingBuffer;

extern RingBuffer usart1_rx_buffer;  // USART1���ջ��λ���??
extern RingBuffer usart2_rx_buffer;  // USART2���ջ��λ���??
extern RingBuffer usart3_rx_buffer;  // USART3���ջ��λ���??


void RingBuffer_Init(RingBuffer *rb);
void RingBuffer_Write(RingBuffer *rb, uint8_t data);
uint8_t RingBuffer_Read(RingBuffer *rb);

#ifdef __cplusplus
}
#endif

#endif /* __RING_BUFFER_H */
